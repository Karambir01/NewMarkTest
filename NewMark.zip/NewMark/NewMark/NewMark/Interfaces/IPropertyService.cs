﻿using NewMark.Models;

namespace NewMark.Interfaces
{
    public interface IPropertyService
    {
       
            Task<List<Property>> GetPropertiesAsync();

    }
}
