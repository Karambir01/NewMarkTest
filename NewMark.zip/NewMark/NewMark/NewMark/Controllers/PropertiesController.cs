﻿using Microsoft.AspNetCore.Mvc;
using NewMark.Interfaces;

namespace NewMark.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PropertiesController : ControllerBase
    {
        private readonly IPropertyService _propertyService;

        public PropertiesController(IPropertyService propertyService)
        {
            _propertyService = propertyService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var properties = await _propertyService.GetPropertiesAsync();
                return Ok(properties);
            }
            catch
            {
                return StatusCode(500, "Error retrieving property data.");
            }
        }
    }
}
