﻿using NewMark.Interfaces;
using NewMark.Models;
using System.Text.Json;
using Azure.Storage.Blobs;
using System.Text.Json;

namespace NewMark.Services
{
    public class PropertyService : IPropertyService
    {
        private readonly IConfiguration _config;

        public PropertyService(IConfiguration config)
        {
            _config = config;
        }

        public async Task<List<Property>> GetPropertiesAsync()
        {
            var blobUrl = _config["AzureBlob:Url"];
            var sasToken = _config["AzureBlob:SasToken"];

            var fullUri = $"{blobUrl}{sasToken}";
            var blobClient = new BlobClient(new Uri(fullUri));

            using var stream = await blobClient.OpenReadAsync();
            try
            {
                var properties = await JsonSerializer.DeserializeAsync<List<Property>>(stream, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return properties ?? new List<Property>();  // Default to empty list if deserialization fails
            }
            catch (JsonException ex)
            {
                // Handle JSON parsing errors gracefully
                throw new ApplicationException("Error deserializing JSON from Blob storage", ex);
            }
        }
    }
}
