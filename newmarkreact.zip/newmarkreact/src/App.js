import React, { useEffect, useState } from "react";
import axios from "axios";
import PropertyList from "./components/PropertyList";

function App() {
  const [properties, setProperties] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5035/api/properties")
      .then((res) => setProperties(res.data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="App" style={{ padding: "20px" }}>
      <h1>Property Hierarchy Viewer</h1>
      <PropertyList properties={properties} />
    </div>
  );
}

export default App;
