import React, { useState } from "react";
import SpaceItem from "./SpaceItem";

const PropertyItem = ({ property }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{ border: "1px solid #ccc", padding: 15, marginBottom: 20 }}>
      <h2 style={{ cursor: "pointer" }} onClick={() => setExpanded(!expanded)}>
        {property.propertyName} {expanded ? "▲" : "▼"}
      </h2>

      {expanded && (
        <>
          <p><strong>Features:</strong> {property.features.join(", ")}</p>
          <p><strong>Highlights:</strong> {property.highlights.join(", ")}</p>
          <p><strong>Transportation:</strong></p>
          <ul>
            {property.transportation.map((t, i) => (
              <li key={i}>
                {t.type} - {t.line ?? t.station ?? "N/A"} ({t.distance})
              </li>
            ))}
          </ul>

          <h4>Spaces:</h4>
          {property.spaces.map((space) => (
            <SpaceItem key={space.spaceId} space={space} />
          ))}
        </>
      )}
    </div>
  );
};

export default PropertyItem;
