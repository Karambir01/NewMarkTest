import React, { useState } from "react";

const SpaceItem = ({ space }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{ marginLeft: 20, marginBottom: 10 }}>
      <h5 style={{ cursor: "pointer" }} onClick={() => setExpanded(!expanded)}>
        {space.spaceName} {expanded ? "▲" : "▼"}
      </h5>

      {expanded && (
        <ul>
          {space.rentRoll.map((entry, index) => (
            <li key={index}>{entry.month}: ${entry.rent}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SpaceItem;
